export const ACTIVE_CITY = 'bowling-green-oh';
